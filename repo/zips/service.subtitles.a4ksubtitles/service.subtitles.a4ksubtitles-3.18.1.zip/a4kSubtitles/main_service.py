# -*- coding: utf-8 -*-

from a4kSubtitles import api, service

if __name__ == '__main__':
    service.start(api.A4kSubtitlesApi())
